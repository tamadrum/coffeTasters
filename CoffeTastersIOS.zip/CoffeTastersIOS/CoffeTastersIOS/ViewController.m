//
//  ViewController.m
//  CoffeTastersIOS
//
//  Created by Ettore Luglio on 11/27/16.
//  Copyright © 2016 Tamadrum. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
