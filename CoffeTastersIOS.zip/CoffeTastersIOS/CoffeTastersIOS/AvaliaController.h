//
//  AvaliaController.h
//  CoffeTastersIOS
//
//  Created by Ettore Luglio on 12/2/16.
//  Copyright © 2016 Tamadrum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AvaliaController : UIViewController

@end
