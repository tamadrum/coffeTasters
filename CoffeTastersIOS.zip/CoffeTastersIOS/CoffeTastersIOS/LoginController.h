//
//  LoginController.h
//  CoffeTastersIOS
//
//  Created by Ettore Luglio on 12/1/16.
//  Copyright © 2016 Tamadrum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface LoginController : UIViewController

@property (weak, nonatomic) IBOutlet FBSDKLoginButton *loginButton;

@property (weak, nonatomic) IBOutlet UILabel *lblLoginStatus;

@property (weak, nonatomic) IBOutlet UILabel *lblUsername;

@property (weak, nonatomic) IBOutlet UILabel *lblEmail;

//@property (weak, nonatomic) IBOutlet FBProfilePictureView *profilePicture;

@end
