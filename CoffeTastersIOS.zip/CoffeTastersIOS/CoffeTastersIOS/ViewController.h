//
//  ViewController.h
//  CoffeTastersIOS
//
//  Created by Ettore Luglio on 11/27/16.
//  Copyright © 2016 Tamadrum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

