//
//  Flavor.m
//  CoffeTastersIOS
//
//  Created by Ettore Luglio on 11/27/16.
//  Copyright © 2016 Tamadrum. All rights reserved.
//

#import "Flavor.h"

@implementation Flavor

@end
